import cv2, os, time

USER_NAME = "guilherme"
VIDEO     = "face_app/videos/guilherme-dev.mov"
SAVE_DIR  = f"face_app/data/{USER_NAME}"
CASCADE   = "face_app/haar/haarcascade_frontalface_default.xml"

os.makedirs(SAVE_DIR, exist_ok=True)
cap = cv2.VideoCapture(VIDEO)
detector = cv2.CascadeClassifier(CASCADE)

SAVE_EVERY_N_FRAMES = 10   
MIN_FACE = (100, 100)
TARGET_SIZE = (400, 400) 

def expand_box(x, y, w, h, img_w, img_h, scale=1.3):
    cx, cy = x + w/2, y + h/2
    new_w, new_h = w * scale, h * scale
    nx = int(max(0, cx - new_w/2))
    ny = int(max(0, cy - new_h/2))
    nx2 = int(min(img_w, cx + new_w/2))
    ny2 = int(min(img_h, cy + new_h/2))
    return nx, ny, nx2 - nx, ny2 - ny

count, frame_id = 0, 0
while True:
    ok, frame = cap.read()
    if not ok:
        break
    frame_id += 1

    if frame_id % SAVE_EVERY_N_FRAMES != 0:
        continue

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector.detectMultiScale(
        gray, scaleFactor=1.2, minNeighbors=5, minSize=MIN_FACE
    )

    H, W = gray.shape[:2]
    for (x,y,w,h) in faces:
        ex, ey, ew, eh = expand_box(x, y, w, h, W, H, scale=1.3)
        roi = gray[ey:ey+eh, ex:ex+ew]
        roi = cv2.resize(roi, TARGET_SIZE)

        path = os.path.join(SAVE_DIR, f"{int(time.time()*1000)}.jpg")
        cv2.imwrite(path, roi)
        count += 1

cap.release()
print(f"[OK] Salvei {count} recortes de rosto em {SAVE_DIR}")