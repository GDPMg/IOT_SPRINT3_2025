import cv2, json, numpy as np
from collections import deque, Counter

CASCADE_FRONTAL = "face_app/haar/haarcascade_frontalface_default.xml"
CASCADE_PROFILE = "face_app/haar/haarcascade_profileface.xml"
MODEL_PATH      = "face_app/models/lbph.yml"
LABELS_PATH     = "face_app/models/labels.json"
VIDEO           = "face_app/videos/guilherme.mov"

TARGET_SIZE = (200, 200)   
THRESHOLD   = 80.0         
DET_SCALE   = 1.1          
DET_NEIGH   = 4
DET_MIN     = (80, 80)
EXPAND      = 1.25         
SMOOTH_N    = 7            


def expand_box(x,y,w,h,W,H,scale=1.25):
    cx, cy = x + w/2.0, y + h/2.0
    nw, nh = w*scale, h*scale
    nx = int(max(0, cx - nw/2.0)); ny = int(max(0, cy - nh/2.0))
    nx2 = int(min(W, cx + nw/2.0)); ny2 = int(min(H, cy + nh/2.0))
    return nx, ny, max(1, nx2-nx), max(1, ny2-ny)

def best_face_union(gray, det_frontal, det_profile):
    faces = []
    faces.extend(det_frontal)
    faces.extend(det_profile)
    if not faces: return None
    return max(faces, key=lambda r: r[2]*r[3])

detF = cv2.CascadeClassifier(CASCADE_FRONTAL)
detP = cv2.CascadeClassifier(CASCADE_PROFILE)
if detF.empty() or detP.empty():
    raise RuntimeError("Falha ao carregar cascades. Verifique caminhos dos XMLs.")

rec = cv2.face.LBPHFaceRecognizer_create(); rec.read(MODEL_PATH)
with open(LABELS_PATH, "r", encoding="utf-8") as f:
    labels = {int(k): v for k, v in json.load(f).items()}

cap = cv2.VideoCapture(VIDEO)
tracker = None
have_track = False
vote_buf = deque(maxlen=SMOOTH_N)

USE_CLAHE = False
clahe = cv2.createCLAHE(2.0, (8,8)) if USE_CLAHE else None

print("[INFO] Pressione 'q' para sair.")
while True:
    ok, frame = cap.read()
    if not ok: break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    H, W = gray.shape[:2]

    facesF = detF.detectMultiScale(gray, DET_SCALE, DET_NEIGH, minSize=DET_MIN)

    flipped = cv2.flip(gray, 1)
    facesRight = detP.detectMultiScale(gray, DET_SCALE, DET_NEIGH, minSize=DET_MIN)
    facesLeft_f = detP.detectMultiScale(flipped, DET_SCALE, DET_NEIGH, minSize=DET_MIN)
    facesLeft = []
    for (x,y,w,h) in facesLeft_f:
        facesLeft.append((W - x - w, y, w, h))

    face = best_face_union(gray, list(facesF) + list(facesRight), facesLeft)

    if face is not None:
        x,y,w,h = face
        ex,ey,ew,eh = expand_box(x,y,w,h,W,H,EXPAND)

        roi = gray[ey:ey+eh, ex:ex+ew]
        if clahe is not None:
            roi = clahe.apply(roi)
        roi = cv2.resize(roi, TARGET_SIZE)

        label_id, conf = rec.predict(roi)
        name = labels.get(label_id, "desconhecido")
        is_known = conf <= THRESHOLD

        vote_buf.append(name if is_known else "desconhecido")
        final, cnt = Counter(vote_buf).most_common(1)[0]

        final_known = (final != "desconhecido")
        color = (0,255,0) if final_known else (0,0,255)
        status = "Face ID Reconhecido" if final_known else "Face ID Irreconhecivel"

        cv2.rectangle(frame, (ex,ey), (ex+ew,ey+eh), color, 2)
        cv2.putText(frame, status, (ex, ey-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

        tracker = cv2.TrackerCSRT_create()
        tracker.init(frame, (ex, ey, ew, eh))
        have_track = True

    else:
        if have_track and tracker is not None:
            ok_t, box = tracker.update(frame)
            if ok_t:
                ex, ey, ew, eh = map(int, box)
                roi = gray[ey:ey+eh, ex:ex+ew]
                if roi.size > 0:
                    if clahe is not None:
                        roi = clahe.apply(roi)
                    roi = cv2.resize(roi, TARGET_SIZE)
                    label_id, conf = rec.predict(roi)
                    name = labels.get(label_id, "desconhecido")
                    is_known = conf <= THRESHOLD
                    vote_buf.append(name if is_known else "desconhecido")
                    final, cnt = Counter(vote_buf).most_common(1)[0]
                    color = (0,255,0) if final != "desconhecido" else (0,0,255)
                    text  = f"{final} ({conf:.0f})"
                    cv2.rectangle(frame, (ex,ey), (ex+ew,ey+eh), color, 2)
                    cv2.putText(frame, text, (ex, ey-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
            else:
                have_track = False

    cv2.imshow("Reconhecimento em vídeo (multi-ângulo + tracker)", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'): break

cap.release()
cv2.destroyAllWindows()