import cv2, os, numpy as np, json

DATA_DIR  = "face_app/data"
MODEL_DIR = "face_app/models"
os.makedirs(MODEL_DIR, exist_ok=True)

MODEL_PATH = os.path.join(MODEL_DIR, "lbph.yml")
LABELS_PATH = os.path.join(MODEL_DIR, "labels.json")

recognizer = cv2.face.LBPHFaceRecognizer_create(
    radius=2, neighbors=8, grid_x=8, grid_y=8
)

images, labels, label_map = [], [], {}
label_id = 0

for user in sorted(os.listdir(DATA_DIR)):
    user_dir = os.path.join(DATA_DIR, user)
    if not os.path.isdir(user_dir): continue
    label_map[label_id] = user
    for fname in os.listdir(user_dir):
        if fname.lower().endswith(".jpg"):
            img = cv2.imread(os.path.join(user_dir, fname), cv2.IMREAD_GRAYSCALE)
            if img is None: continue
            images.append(img)
            labels.append(label_id)
    label_id += 1

if not images:
    raise SystemExit("Nenhuma imagem encontrada em data/<usuario>/")

recognizer.train(images, np.array(labels))
recognizer.write(MODEL_PATH)

with open(LABELS_PATH, "w", encoding="utf-8") as f:
    json.dump(label_map, f, ensure_ascii=False, indent=2)

print(f"[OK] Modelo salvo em {MODEL_PATH}")